#include <Arduino.h>

// Definisi Pin
const int led1 = PA0;
const int led2 = PA1;
const int btn1 = PB4;
const int btn2 = PB5;

void setup() {
  // USART1 (PA9=TX, PA10=RX) dimulai secara default pada Serial
  Serial.begin(115200);
  
  pinMode(led1, OUTPUT);
  pinMode(led2, OUTPUT);
  
  // Menggunakan Pull-up internal agar rangkaian simpel (Button ke GND)
  pinMode(btn1, INPUT_PULLUP);
  pinMode(btn2, INPUT_PULLUP);
}

void loop() {
  // 1. MONITORING: Baca tombol (LOW saat ditekan)
  int s1 = (digitalRead(btn1) == LOW) ? 1 : 0;
  int s2 = (digitalRead(btn2) == LOW) ? 1 : 0;

  // Kirim data ke HMI dengan format "B1:x,B2:x"
  Serial.print("B1:"); Serial.print(s1);
  Serial.print(",B2:"); Serial.println(s2);

  // 2. CONTROL: Baca perintah dari HMI
  if (Serial.available() > 0) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim();

    if (cmd == "L1_ON") digitalWrite(led1, HIGH);
    else if (cmd == "L1_OFF") digitalWrite(led1, LOW);
    else if (cmd == "L2_ON") digitalWrite(led2, HIGH);
    else if (cmd == "L2_OFF") digitalWrite(led2, LOW);
  }

  delay(50); // Stabilitas komunikasi
}